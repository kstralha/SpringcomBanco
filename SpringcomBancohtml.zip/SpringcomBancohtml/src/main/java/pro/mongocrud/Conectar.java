package pro.mongocrud;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import org.bson.Document;

public class Conectar {

    public void getValues() {
        System.out.println("getValues");
        MongoClient mongo = new MongoClient("localhost", 27017);
        MongoDatabase db = mongo.getDatabase("cliente");
        MongoCollection<Document> docs = db.getCollection("cadastro");
        for (Document doc : docs.find()) {
            System.out.println("item: " + doc);
        }
        System.out.println("getValues ok");
    }

    public int selectValues(int x) {
        int y = 0;
        System.out.println("Select Values");
        MongoClient mongo = new MongoClient("localhost", 27017);
        MongoDatabase db = mongo.getDatabase("cliente");
        MongoCollection<Document> docs = db.getCollection("cadastro");
        for (Document doc : docs.find()) {
            System.out.println("item: " + doc);
        }
        y = Integer.parseInt(docs.find(Filters.eq("_id", x)).toString());
       
        System.out.println("Select id ok");
        return y;
    }

    public void insertValues() {
        System.out.println("insertValues");
        //conexão mongo
        MongoClient mongo = new MongoClient("localhost", 27017);
        MongoDatabase db = mongo.getDatabase("cliente");
        MongoCollection<Document> docs = db.getCollection("cadastro");
        Entrada user = createUser();//cria um user obj //da classe 
        //conectar, chamando o método createUser()- logo abaixo
        Document doc = createDocument(user);//cria um doc 
        //que referencia o conteúdo de user do createDocument()
        //obs, o Banco só entende objetos do tipo Document, 
        docs.insertOne(doc);//insere no mongo o conteúdo de doc      
        System.out.println("insertValues ok");
    }

    public Entrada createUser() {
        //esse método deve ser uma entrada externa
        //(interface, scanner ou JOptionPanel
        Entrada u = new Entrada();
        u.setId(5);
        u.setNome("Crishna Irion");
        u.setProfissao("Professora");
        u.setCidadenasc("Santa Cruz - RS");
        u.setEsta_trabalhando(true);
        return u;
    }

    public Document createDocument(Entrada user) {
        Document docBuilder = new Document();
        docBuilder.append("_id", user.getId());
        docBuilder.append("nome", user.getNome());
        docBuilder.append("cidadenasc", user.getCidadenasc());
        docBuilder.append("profissão", user.getProfissao());
        docBuilder.append("esta_trabalhando", user.isEsta_trabalhando());
        return docBuilder;
    }

    public void updateValues() {
        System.out.println("updateValues");
        Entrada user = createUser();
        MongoClient mongo = new MongoClient("localhost", 27017);
        MongoDatabase db = mongo.getDatabase("cliente");
        MongoCollection<Document> docs = db.getCollection("cadastro");
        docs.updateOne(Filters.eq("_id", 5),
                Updates.set("cidadenasc", "Santa Maria - RS"));
        System.out.println("Documento teve sucesso no update...");
        for (Document doc : docs.find()) {
            System.out.println("item update: " + doc);
        }
    }

    public void deleteValues() {
        System.out.println("deleteValues");
        Entrada user = createUser();
        MongoClient mongo = new MongoClient("localhost", 27017);
        MongoDatabase db = mongo.getDatabase("cliente");
        MongoCollection<Document> docs = db.getCollection("cadastro");

        docs.deleteOne(Filters.eq("_id", 4));
        System.out.println("Documento teve sucesso no delete...");
        for (Document doc : docs.find()) {
            System.out.println("item deleted: " + doc);
        }
    }
}
