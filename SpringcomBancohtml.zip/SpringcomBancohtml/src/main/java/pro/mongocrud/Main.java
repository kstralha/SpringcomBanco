package pro.mongocrud;

public class Main {
    public static void main(String[] args) {
        Conectar con = new Conectar();
       
        //con.insertValues();
        con.updateValues();        
       
        //con.deleteValues();
        
        con.getValues();
 }
}