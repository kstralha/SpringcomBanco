package BancoAppSpring;

import conecta.conectar;
import java.sql.Connection;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import pro.mongocrud.Conectar;

@Controller
public class WebController {

    //Default method GET
    @RequestMapping("/form")//é um mapeamento de quem chama o oi
    public String DigaOla(Model modelo) {
        System.out.println("Dizendo Olá: ");
        modelo.addAttribute("mensagem", "Bem vind@!");//quando usar o atributo mensagem, aparece o texto
        return "form";
    }

    @RequestMapping(value = "/respostaForm", method = RequestMethod.POST)//é um mapeamento de quem chama o oi
    public String DigaOla1(Model modelo, String fname, String email) {
        System.out.println("mensagem 1");
        modelo.addAttribute("mensagem1", "Bem vind@!");//quando usar o atributo mensagem, aparece o texto
        System.out.println("Nome: " + fname);
        System.out.println("Email: " + email);
        modelo.addAttribute("mensagem2", "Bem vind@ " + fname + ", email: " + email + " !");
        conectar obj = new conectar();
        Connection conexao = obj.connectionMySql();
        obj.dataBaseInsert(fname, email);
        obj.consulta(conexao);
        return "respostaForm";
    }

    @RequestMapping(value = "/bancoconecta", method = RequestMethod.POST)
    public String Banco(Model modelo1, String code) {
        System.out.println("Banco Conecta");
        conectar obj = new conectar();
        Connection conexao = obj.connectionMySql();
        System.out.println("Cod: " + code);
        String x = obj.dataBaseSelect(Integer.parseInt(code));
        modelo1.addAttribute("mensagem3", "Olá, " + x + ", como você está?!");
        obj.closeConnectionMySql(conexao);
        return "bancoconecta";
    }

    @RequestMapping("/banco")//é um mapeamento de quem chama o oi
    public String Banco2(Model modelo) {
        System.out.println("Dizendo Banco: ");
        return "banco";  
    }
    
    
    @RequestMapping(value = "/bancoMongo", method = RequestMethod.POST)
    public String BancoMongo(Model modelo1, String code) {
        System.out.println("Banco Mongo");
        Conectar con = new Conectar();                    
        con.getValues();
        System.out.println("Cod: " + code);
        int x = con.selectValues(Integer.parseInt(code));
        modelo1.addAttribute("mensagem4", "Olá, " + x + ", como você está?!");
       
        return "bancoMongo";
}
    
    @RequestMapping("/bancoM")//é um mapeamento de quem chama o oi
    public String BancoMDB(Model modelo) {
        System.out.println("Dizendo BancoMongo: ");
        return "bancoM";  
    }
    
}